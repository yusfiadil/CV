function tentangsaya() {
    document.getElementById("tentang").innerHTML = " Nama Saya Yusfi Adil Amrullah. Lahir Di Jember, Jawa Timur pada tanggal 11 Oktober 1997. Saya memiliki kondisi kesehatan yang baik, loyalitas tinggi, jujur, ulet, cepat memahami bidang baru yang sedang dipahami dan dikerjakan.";
}